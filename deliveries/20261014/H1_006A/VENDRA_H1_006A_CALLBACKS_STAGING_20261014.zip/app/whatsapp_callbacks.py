"""Ponte de entrada/status sem fila, IA ou rotas administrativas.

Processo separado, configuracao explicita e SDK restrito ao backend. Nao importa
app.main, demo_store nem os routers do portal. Reutilizavel na hospedagem.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
import hmac
import base64
import binascii
import re
from urllib.parse import urlsplit

from dotenv import dotenv_values
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field, field_validator, model_validator


def canonical_phone(value: str) -> str:
    digits = re.sub(r'\D', '', value)
    if not re.fullmatch(r'55\d{10,11}', digits):
        raise ValueError('Telefone BR com DDI invalido.')
    if len(digits) == 13 and digits[4] == '9':
        digits = digits[:4] + digits[5:]
    return digits


@dataclass(frozen=True)
class BridgeConfig:
    environment: str
    project_ref: str
    supabase_url: str
    backend_key: str = field(repr=False)
    webhook_secret: str = field(repr=False)
    phone_number_id: str
    business_account_id: str
    allowed_phones: tuple[str, ...]

    def validate(self) -> None:
        if self.environment not in {'staging', 'production'}:
            raise ValueError('Ambiente explicito obrigatorio.')
        parsed = urlsplit(self.supabase_url)
        if (not re.fullmatch(r'[a-z0-9]{20}', self.project_ref)
                or parsed.scheme != 'https' or parsed.netloc != self.project_ref+'.supabase.co'
                or parsed.path not in ('', '/') or parsed.query or parsed.fragment):
            raise ValueError('Projeto Supabase divergente da configuracao explicita.')
        if (len(self.backend_key) < 32 or not self.backend_key.startswith(('sb_secret_', 'eyJ'))
                or len(self.webhook_secret) < 32):
            raise ValueError('Credenciais backend/webhook ausentes ou invalidas.')
        if not self.phone_number_id.isdigit() or not self.business_account_id.isdigit():
            raise ValueError('Conta/remetente Meta obrigatorios.')
        if not self.allowed_phones:
            raise ValueError('Destinatarios explicitamente autorizados obrigatorios.')
        for phone in self.allowed_phones:
            canonical_phone(phone)


def load_config(path: Path) -> BridgeConfig:
    """Nao herda .env, variaveis globais, sessoes ou estado do principal."""
    if not path.is_file():
        raise ValueError('Arquivo exclusivo da ponte nao encontrado.')
    values = dotenv_values(path, interpolate=False)
    required = ('APP_ENV', 'VENDRA_BRIDGE_PROJECT_REF', 'SUPABASE_URL',
                'SUPABASE_SERVICE_ROLE_KEY', 'MAKE_WEBHOOK_SECRET',
                'META_PHONE_NUMBER_ID', 'META_WABA_ID', 'VENDRA_BRIDGE_ALLOWED_PHONES')
    if any(not values.get(key) for key in required):
        raise ValueError('Configuracao exclusiva da ponte incompleta.')
    config = BridgeConfig(
        environment=values['APP_ENV'], project_ref=values['VENDRA_BRIDGE_PROJECT_REF'],
        supabase_url=values['SUPABASE_URL'], backend_key=values['SUPABASE_SERVICE_ROLE_KEY'],
        webhook_secret=values['MAKE_WEBHOOK_SECRET'], phone_number_id=values['META_PHONE_NUMBER_ID'],
        business_account_id=values['META_WABA_ID'],
        allowed_phones=tuple(p.strip() for p in values['VENDRA_BRIDGE_ALLOWED_PHONES'].split(',') if p.strip()))
    config.validate()
    return config


class MetaSource(BaseModel):
    phone_number_id: str = Field(min_length=1, max_length=80)
    business_account_id: str = Field(min_length=1, max_length=80)
    occurred_at: datetime

    @field_validator('occurred_at')
    @classmethod
    def timezone_required(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError('Timestamp precisa incluir fuso horario.')
        return value.astimezone(timezone.utc)


class Inbound(MetaSource):
    phone: str = Field(min_length=8, max_length=30)
    name: str | None = Field(default=None, max_length=180)
    message: str | None = Field(default=None, min_length=1, max_length=10000)
    message_base64: str | None = Field(default=None, max_length=56000)
    name_base64: str | None = Field(default=None, max_length=1000)
    external_message_id: str = Field(min_length=1, max_length=430)

    @model_validator(mode='after')
    def decode_make_text(self):
        # O Make usa base64 para que aspas, quebras e Unicode nao quebrem JSON raw.
        if (self.message is None) == (self.message_base64 is None):
            raise ValueError('Informe exatamente uma representacao da mensagem.')
        try:
            if self.message_base64 is not None:
                self.message = base64.b64decode(self.message_base64, validate=True).decode('utf-8')
            if self.name_base64 is not None:
                if self.name is not None: raise ValueError('Nome duplicado.')
                self.name = base64.b64decode(self.name_base64, validate=True).decode('utf-8')
        except (binascii.Error, UnicodeError):
            raise ValueError('Texto codificado invalido.') from None
        if not self.message.strip() or len(self.message) > 10000 or len(self.name or '') > 180:
            raise ValueError('Texto fora do limite.')
        return self


class ProviderStatus(MetaSource):
    provider_message_id: str = Field(min_length=1, max_length=430)
    status: str = Field(pattern='^(sent|delivered|read|failed)$')
    recipient_id: str = Field(min_length=8, max_length=30)
    error_message: str | None = Field(default=None, max_length=1000)


def create_app(config: BridgeConfig, *, client=None) -> FastAPI:
    config.validate()
    if client is None:
        from supabase import create_client
        client = create_client(config.supabase_url, config.backend_key)
    allowed = {canonical_phone(p) for p in config.allowed_phones}
    app = FastAPI(title='VENDRA - callbacks WhatsApp', docs_url=None,
                  redoc_url=None, openapi_url=None)

    @app.middleware('http')
    async def headers(request, call_next):
        # Limite aplicado antes de desserializar JSON (inclui corpos chunked).
        if request.method == 'POST':
            size = 0
            chunks = []
            async for chunk in request.stream():
                size += len(chunk)
                if size > 65536:
                    from fastapi.responses import JSONResponse
                    return JSONResponse({'detail': 'Payload excede 64 KB.'}, status_code=413)
                chunks.append(chunk)
            request._body = b''.join(chunks)
        response = await call_next(request)
        response.headers['Cache-Control'] = 'no-store'
        response.headers['X-Content-Type-Options'] = 'nosniff'
        return response

    def authorize(secret: str | None, payload: MetaSource, phone: str) -> bool:
        if not secret or not hmac.compare_digest(secret.encode('utf-8'), config.webhook_secret.encode('utf-8')):
            raise HTTPException(401, 'Webhook nao autorizado.')
        if (payload.phone_number_id != config.phone_number_id
                or payload.business_account_id != config.business_account_id):
            raise HTTPException(403, 'Conta/remetente Meta divergentes.')
        try:
            return canonical_phone(phone) in allowed
        except ValueError:
            raise HTTPException(422, 'Telefone invalido.') from None

    def rpc(name: str, params: dict) -> dict:
        try:
            result = client.rpc(name, params).execute().data
        except Exception as exc:
            code = str(getattr(exc, 'code', ''))
            status = 409 if code == 'PT409' else 422 if code == '22023' else 503
            raise HTTPException(status, 'Callback nao persistido; consultar o diagnostico do servidor.') from None
        if not isinstance(result, dict) or result.get('accepted') is not True:
            raise HTTPException(503, 'Banco nao confirmou o callback.')
        return result

    @app.get('/health')
    def health():
        return {'status': 'ok', 'environment': config.environment,
                'component': 'whatsapp_callbacks_v1', 'external_sends_enabled': False,
                'ai_enabled': False, 'persistence': 'supabase'}

    @app.post('/webhooks/make/whatsapp', status_code=202)
    def inbound(payload: Inbound, x_webhook_secret: str | None = Header(default=None)):
        if not authorize(x_webhook_secret, payload, payload.phone):
            return {'accepted': True, 'ignored': True, 'reason': 'outside_test_scope'}
        result = rpc('vendra_whatsapp_receive_v1', {
            'p_phone': payload.phone, 'p_name': payload.name, 'p_body': payload.message,
            'p_external_message_id': payload.external_message_id,
            'p_occurred_at': payload.occurred_at.isoformat()})
        result['automation'] = {'enabled': False, 'mode': 'human', 'connected': False,
            'route_to_ai': False, 'should_respond': False, 'control_version': 1,
            'make_instruction': 'STOP_AT_VENDRA', 'thread_id': 'VENDRA-'+str(result['ticket_id'])}
        return result

    @app.post('/webhooks/make/whatsapp/provider-status', status_code=202)
    def provider_status(payload: ProviderStatus, x_webhook_secret: str | None = Header(default=None)):
        if not authorize(x_webhook_secret, payload, payload.recipient_id):
            return {'accepted': True, 'ignored': True, 'reason': 'outside_test_scope'}
        return rpc('vendra_whatsapp_status_v1', {
            'p_provider_message_id': payload.provider_message_id, 'p_status': payload.status,
            'p_occurred_at': payload.occurred_at.isoformat(), 'p_recipient_id': payload.recipient_id,
            'p_error_message': payload.error_message})
    return app
