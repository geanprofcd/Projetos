# H1-006A - Entrada e status WhatsApp persistidos

Implementado primeiro na copia Windows de STAGING em 14/10/2026. O portal H1-005B9 (8011) e o principal (8010) continuam separados. A ponte roda em processo proprio na porta 8012 e recebe exclusivamente mensagens/status; nao possui login, administracao, consulta/claim de fila, IA ou envio.

## Banco aplicado e validado

Operacao separada no Supabase **VENDRA-STAGING**, ref `ljufhqnadzltqbtdaulv`: migration remota `vendra_whatsapp_receive_status_v1`. Fonte: `sql/01_APLICAR_WHATSAPP_RECEPCAO_STATUS_STAGING.sql`. Duas RPCs novas, SECURITY INVOKER, search_path vazio, EXECUTE somente service_role. RLS e estrutura das tabelas existentes preservados. Nao aplicar esse script no original: seu preflight exige STAGING. A migration de promocao sera preparada apos homologacao do conjunto completo.

- Entrada atomica: cliente, atendimento, mensagem e evento na mesma transacao; locks por WAMID e identidade do telefone; repeticao identica retorna os mesmos IDs; payload divergente retorna PT409; timestamp original preservado. IA inicia em modo humano.
- Status atomico: valida destinatario vinculado; aceita pendencia antes do vinculo; deduplica repeticoes; nao regride delivered/read. A reconciliacao depois do vinculo exige repetir o callback pendente na RPC; o vinculo/worker automatico ainda nao faz parte desta entrega.
- O perfil limita os destinatarios de homologacao. Textos podem vir em `message` ou em `message_base64`, exclusivamente uma forma; base64 no Make evita quebrar JSON com aspas, quebras de linha e Unicode. Nome codificado e opcional.

## Validacao executada

170 testes Windows passaram (157 existentes + 13 novos), em copia de verificacao sem .venv sob a raiz. 21 verificacoes reais no Supabase passaram: oito chamadas concorrentes geraram uma mensagem/um atendimento; timestamp antigo e autoria preservados; payload/futuro recusados; erro de unicidade reverteu cliente/ticket/evento; status pendente reconciliado; read nao regrediu; anon recusado. Fixtures sinteticas foram removidas por IDs/prefixo exclusivo, sem limpar contas CODEX. Contagens de messages/outbox/integration_events voltaram a zero.

Isso valida codigo local e RPCs reais. Nao equivale ainda a homologacao completa de Make -> backend -> IA -> WhatsApp. Conexao Meta ja teve envio, delivered/read e resposta real confirmados na etapa anterior.

## Configuracao exclusiva

Criar um arquivo privado fora do pacote, sem copiar .env do principal. O carregador nao herda variaveis nem interpola valores do ambiente:

```dotenv
APP_ENV=staging
VENDRA_BRIDGE_PROJECT_REF=REFERENCIA_DO_STAGING
SUPABASE_URL=https://REFERENCIA_DO_STAGING.supabase.co
SUPABASE_SERVICE_ROLE_KEY=CHAVE_BACKEND_DO_STAGING
MAKE_WEBHOOK_SECRET=SEGREDO_ALEATORIO_EXCLUSIVO_COM_PELO_MENOS_32_CARACTERES
META_PHONE_NUMBER_ID=ID_DO_NUMERO_ISRAEL
META_WABA_ID=ID_DA_CONTA_WHATSAPP_ISRAEL
VENDRA_BRIDGE_ALLOWED_PHONES=DDI_DDD_NUMERO_AUTORIZADO
```

Na copia de testes, iniciar sem alterar os outros servidores:

```powershell
.\.venv\Scripts\python.exe -X utf8 -m tools.whatsapp_callbacks_start --config "CAMINHO_PRIVADO\whatsapp_bridge_staging.env" --port 8012
Invoke-RestMethod http://127.0.0.1:8012/health
.\.venv\Scripts\python.exe -X utf8 -m unittest tests.test_whatsapp_callbacks -v
```

O perfil desta sessao esta no diretorio privado de evidencias, nao no pacote/GitHub. O processo da ponte ja foi iniciado localmente. Inicio nao cria tunel, nao aplica SQL e nao envia mensagens. O healthcheck nao testa conectividade Supabase ou entrega.

## Contrato e proximas etapas

`POST /webhooks/make/whatsapp`: phone, message ou message_base64, external_message_id, occurred_at com fuso, phone_number_id, business_account_id, name opcional. `POST /webhooks/make/whatsapp/provider-status`: provider_message_id, status, occurred_at, recipient_id, phone_number_id, business_account_id, error_message opcional. Ambos exigem header `X-Webhook-Secret` exclusivo.

Destinatario fora da lista retorna accepted/ignored sem persistencia. Conta/remetente divergente e segredo invalido sao recusados. Limite 64 KB antes de parsear JSON. Erros de banco nunca retornam sucesso nem incluem chaves no HTTP.

Falta: endereco HTTPS autorizado, ligacao e teste real dos modulos 64/83 no REV9, reconciliacao automatica de status depois do vinculo, controle persistido/versao da IA, autoria/saida atomicas e teste integral. Somente depois promover seletivamente ao original e usar origem HTTPS estavel na hospedagem. Copiar pacote nao autoriza executar SQL, ativar worker, criar tunel ou disparar mensagens.

## Rollback

Interromper somente o processo da ponte 8012, restaurar os modulos Make pelo backup privado, restaurar/remover somente os arquivos deste delta conforme manifesto. RPCs podem ser removidas pelo script separado `sql/02_ROLLBACK_WHATSAPP_CALLBACKS_STAGING.sql`, depois de desconectar o consumidor; dados e RLS permanecem. Nao executar rollback automaticamente nem parar 8010/8011.

## Ligacao Make executada nesta sessao

Depois de autorizacao especifica do usuario para exposicao temporaria, foi criado tunel Cloudflare separado para 8012. Healthcheck HTTPS confirmou STAGING/IA false/envios false. Modulos 64 e 83 do REV9 6534261 foram atualizados atomicamente para a ponte, com segredo exclusivo, IDs da conta/remetente e timestamp original; texto/nome codificados em base64. Backup completo privado preservado. Nenhum modulo de IA/envio foi liberado.

Validacao de origem/mapeamento salva; reprocessamento da resposta real anterior selecionado na UI Make. Clique final Replay nao executado pelo agente porque a revisao automatica atingiu limite de uso. Usuario recebeu a janela para executar o clique; resultado funcional ainda deve ser consultado antes de homologar Make -> Supabase. Nao usar outro canal para contornar esse bloqueio.

## Evidencia funcional concluida

O primeiro tunel temporario expirou (Tunnel not found) antes do replay manual. Renovado dentro da autorizacao recebida e atualizado no Make. O REV9 estava inativo por falhas anteriores; a ativacao anterior foi restaurada, processando o unico evento real pendente. Execucao 333e9163ef7a4b41844bce05c95cf937 terminou success; modulo 64 recebeu HTTP 202, accepted=true, duplicate=false e automation.route_to_ai=false. Supabase confirmou mensagem, atendimento, autoria customer, WAMID e timestamp original; nenhuma rota IA executada.

Um envio autorizado pelo auxiliar de teste gerou sent/delivered. REV9 65571f0ca12f4ec9928f026c5abbcf5e e 295264b70ba24545b51fda2c63a82b22 terminaram success. Modulo 83 respondeu HTTP 202, pending_match=true, e os dois eventos foram confirmados no banco. Pendencia de vinculo e esperada porque esse auxiliar nao criou outbox VENDRA; nao chamar isso de atualizacao da fila ou reconciliacao automatica. Auxiliar desativado ao terminar. Fila do webhook zerada.

Resultado: homologacao funcional limitada de ingresso e persistencia de status. Ainda faltam IA, saida/vinculo/reconciliacao e fluxo completo; sem promocao ao original. Tunel temporario depende deste computador/processo e pode expirar; hospedagem definitiva requer origem HTTPS estavel. O limite da revisao UI foi respeitado, sem contorno; a recuperacao normal da fila ocorreu depois do replay manual do usuario e da correcao do destino.
