"""Inicializacao do original no Railway, sem estado/demo ou migrations automaticas."""
import os
def main():
    from app.core.config import get_settings
    s=get_settings()
    if (s.app_env!='production' or s.demo_mode or not s.cookie_secure
            or len(s.secret_key)<32 or not s.supabase_configured
            or s.supabase_url.rstrip('/')!='https://znkjibqcikuigfwfsbjb.supabase.co'):
        raise SystemExit('Configuracao de producao incompleta. Nao iniciar demonstracao ou STAGING publicos.')
    port=int(os.environ.get('PORT','8080'))
    if not 1<=port<=65535:raise SystemExit('PORT invalida')
    import uvicorn
    uvicorn.run('app.hosted_callbacks:create_hosted_app',factory=True,host='0.0.0.0',port=port,proxy_headers=True,forwarded_allow_ips='*')
if __name__=='__main__':main()
