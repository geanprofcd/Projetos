from pathlib import Path
import argparse,json,hashlib,shutil
from datetime import datetime
p=argparse.ArgumentParser();p.add_argument('--destino',required=True);p.add_argument('--aplicar',action='store_true');a=p.parse_args()
base=Path(__file__).resolve().parent;target=Path(a.destino).resolve()
assert (target/'app/services/ticket_attention_service.py').is_file(),'Destino nao contem VENDRA'
manifest=json.loads((base/'manifest.json').read_text(encoding='utf8'))
for e in manifest['files']:
 src=base/e['path'];assert hashlib.sha256(src.read_bytes()).hexdigest()==e['sha256'],e['path']
backup=target/'output/backups'/('midia-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
for e in manifest['files']:
 if not e['path'].startswith('files/'):continue
 rel=Path(e['path']).relative_to('files');out=(target/rel).resolve();assert out.is_relative_to(target)
 if a.aplicar:
  if out.exists():
   saved=backup/rel;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(out,saved)
  out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/e['path'],out)
  assert hashlib.sha256(out.read_bytes()).hexdigest()==e['sha256']
 print(('APLICADO ' if a.aplicar else 'SIMULACAO ')+str(rel))
if a.aplicar:print('Backup: '+str(backup))
