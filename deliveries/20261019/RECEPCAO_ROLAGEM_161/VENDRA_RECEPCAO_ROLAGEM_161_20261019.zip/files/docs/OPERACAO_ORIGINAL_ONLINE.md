# VENDRA original online - integração e operação

## Desenvolvimento v1.60 - 19/10/2026 (somente STAGING)

Recepção de mídia implementada e validada com52 testes Windows,18 verificações funcionais e quatro arquivos próprios pela cópia Make. Ainda falta evento real do WhatsApp e promoção/SQL autorizados para o original. Produção permanece na v1.59, envio de mídias/texto/IA/disparos preservados; os três cenários originais não foram pausados. Ler [VALIDACAO_RECEPCAO_MIDIA_20261019.md](VALIDACAO_RECEPCAO_MIDIA_20261019.md). Não contar upload/download de arquivo próprio como recepção real de lead.


## Estado vigente v1.59 - 18/10/2026

Envio de mídias liberado para clientes reais após autorização específica. PNG/PDF/MP3/MP4 aceitos em teste real STAGING; PDF delivered pelo portal original. Quatro arquivos backend e SQL30 promovidos seletivamente. Deploy abca256d-5fbc-4d3a-8fa0-a158f45ede37. Os três cenários originais Make permanecem ativos: não pausar para desenvolvimento/testes. Recebimento de mídias e gestão Meta pelo portal continuam pendentes. Evidência, limites, segurança e reversão: [VALIDACAO_MIDIA_WHATSAPP_20261016.md](VALIDACAO_MIDIA_WHATSAPP_20261016.md). Seções anteriores a este checkpoint são históricas; pendência antiga de envio de mídia está encerrada.


## Estado vigente: paridade em 16/10/2026

Leia [PARIDADE_ORIGINAL_ONLINE_20261016.md](PARIDADE_ORIGINAL_ONLINE_20261016.md) antes dos checkpoints históricos abaixo. IA, respostas humanas, disparos individuais/listas, cinco etapas do funil e alertas estão integrados. Esta rodada acrescentou Storage privado e convites por link, sem SMTP. Comparação:130 arquivos app idênticos no original Windows/release,104 rotas catalogadas,15 páginas administrativas200. Deploy vigente68d979f1-19c5-4631-b039-32c83dac3648 SUCCESS. Restam transmissão de mídia WhatsApp e gestão Meta no portal com credencial específica; arquivo salvo não significa mensagem enviada. Nenhum dado demo foi promovido. Seções posteriores descrevem a evolução histórica e podem conter pendências já encerradas.

Atualizado em 16/10/2026. Portal: https://vendra-original-production.up.railway.app/login

## Situação efetiva

O portal comercial, o banco original e os callbacks WhatsApp estão hospedados. O fluxo de conversas funciona com Railway, Supabase, Make e Meta, sem depender do Windows ou de túnel temporário. Os arquivos SQL antigos não são carregados na execução: as funções aplicadas ficam no banco. A máquina local continua sendo um local de desenvolvimento e backup.

Após autorização específica do usuário, IA e respostas humanas foram liberadas para clientes reais. `ai_automation` e `make_outbox` estão habilitados no original. O modo humano de atendimentos existentes permanece preservado. Disparos, importação e lote não foram incluídos nessa autorização.

## Evidências reaproveitadas e migração

- SQL21 aplicado exclusivamente no original após autorização: 12 funções homologadas, EXECUTE somente service_role, sem copiar dados STAGING. SQL22 de reversão preparado, não executado.
- Dez callbacks dos cenários originais Make foram migrados para HTTPS no Railway com segredo próprio. Cenários: REV9 6534261 e Disparo Inicial 6561096. Saída humana hospedada: 6659974.
- IA real hospedada: execução `07e22a12e2c042068f85cf5ff5f67330`; uma tentativa, WAMID e status READ no banco original.
- Texto humano real pelo formulário: execução `b1e46f9308ae4362a04e0851103a906d`; um envio, uma tentativa, WAMID e READ no banco original. Evidências reais preservadas.
- Login, permissões Comercial, gravação e persistência após reinício já validados na primeira publicação. Não é necessário repetir esses blocos sem alteração relevante.
- Escopo de destinatários foi liberado explicitamente para conversas de produção. Segredo, conta Meta, telefone válido, reservas e políticas de envio permanecem obrigatórios. Quinze testes distintos dos controles de destinatário/wake passaram após a alteração.

O design comercial permanece preservado. Alterações em formulários são campos ocultos de segurança/idempotência e controles de funções indisponíveis; não houve substituição de layouts pelo protótipo STAGING. Nenhum snapshot integral, credencial ou dado de simulação foi promovido.

## Disparo individual: próximo bloco

Adaptador do formulário comercial preparado a partir do contrato já homologado no STAGING. Vinte e três testes relevantes de contrato/histórico passaram; uma conferência HTTP da tela original confirmou o nonce oculto e bloqueio antes de RPC/transporte quando o canal está desligado. Isso não equivale a envio funcional hospedado.

Release privada `fbbfb26f-0f6e-4e70-b893-ea3412a3bd41` enviada ao Railway. Transporte tem segredo próprio e destinatário de teste restrito. Configurações `dispatch_bridge`/`dispatches` permanecem desligadas e o template Make permanece bloqueado. Autorização específica de um único teste temporário foi solicitada, separadamente da liberação de conversas. Não anunciar Disparo homologado no original antes de WAMID/entrega real pelo portal.

## O que falta

1. Conferir o deploy do adaptador e, com autorização específica, executar um disparo individual pelo portal, conferir vínculo/status e bloquear novamente ao concluir.
2. Consolidar promoção seletiva na pasta original local, backup, hashes e pacote de continuidade. Não expor os arquivos privados do produto no GitHub público.
3. Registrar recuperação mínima e acompanhar prazo/saldo do trial Railway. Nenhum plano pago ou domínio próprio contratado.
4. Encerrar as contas CODEX somente quando o escopo de homologação acordado estiver concluído; preservar administrador e Comercial reais.

Mídia, importação, lote, SMTP/convites e melhorias ficam para uma fase posterior, conforme prioridade do usuário. Não são critérios novos para impedir a operação das conversas já liberadas.

## Comandos de acompanhamento

Não há comando necessário para usar o portal. Manutenção requer token privado já carregado, sem incluí-lo em arquivos públicos:

```powershell
Invoke-RestMethod https://vendra-original-production.up.railway.app/health
Invoke-RestMethod https://vendra-original-production.up.railway.app/callbacks/health
railway deployment list --project caad2a82-373d-441c-8403-f3a7903a264f --environment production --service vendra-original --limit 1 --json
railway logs --project caad2a82-373d-441c-8403-f3a7903a264f --environment production --service vendra-original --lines 30
```

Para publicar, usar somente o caminho absoluto da release privada limpa e conferida, com `--path-as-root`; nunca subir a pasta STAGING ou arquivos `.env`, estado e runtime. SQL e ativação Make são operações separadas da entrega de arquivos. Python Windows deve usar `-X utf8`.

## Disparo individual original concluído - 16/10/2026
Autorização específica recebida; um POST real do formulário original retornou303/sent. Make6561096 execução8ae8ba54b8e5478a8d1fcbed9e04ce31, cinco módulos uma vez, um template enviado. Banco original: dispatch5eb1de1d-7e9c-4da1-bd3a-577e9e2cf6d8, WAMID presente, status delivered, tentativa1, transporte200, vínculos cliente/atendimento/mensagem/oportunidade completos, etapa Novo Lead. Canal dispatch_bridge/dispatches desligado e filtro Make novamente constantefalse ao concluir. IA e make_outbox continuam true conforme liberação regular. Sem lote/importação. Próximo: consolidar promoção seletiva/pacote e recuperação mínima; não repetir o template nem solicitar novo teste para a mesma migração.


## Consolidação final desta entrega
Pasta original Windows atualizada seletivamente:15arquivos, backup output/backups/conversas-original-20261016-125956. Main/base/.env preservados por hash. Extração de recuperação conferiu19arquivos do pacote; isso não é restauração de banco nem reversão de provedor. Histórico Git privado da release:32ae7b1ac4cbcdd892e2f28be48db29c713d2658, sem remoto. Fonte pública sincronizada em desenvolvimento/vendra-staging, checkout permanente atualizado. Pacote SHA256:5dbcd9e781e29e9156e540bab1a0142c8e81634999ffd0b4b3f50aa14dba6195. Mestre152:224p/222históricas, cópias Downloads e Downloads/Automações iguais. Continuidade: manter os segredos privados, preservar banco original e evidências reais, acompanhar trialRailway. A reversão de aplicação deve usar deployment anterior ou backup seletivo; não executar SQL22 automaticamente. Não declarar recuperação integral de banco testada. CODEX permanece até encerramento do escopo acordado.
Entrega: https://github.com/geanprofcd/Projetos/blob/b35e2eb667f1ca6047129a28b7ea4365992f1431/deliveries/20261016/CONVERSAS_ORIGINAL/INSTRUCOES.md
Download: https://raw.githubusercontent.com/geanprofcd/Projetos/b35e2eb667f1ca6047129a28b7ea4365992f1431/deliveries/20261016/CONVERSAS_ORIGINAL/VENDRA_CONVERSAS_ORIGINAL_20261016.zip


## Listas, quantidade e custos - 16/10/2026
Disparo individual regular liberado após autorização específica. SQL23/listas aplicado STAGING e original mediante autorização específica; duas tabelas/quatro funções, RLS/ACLbackend. STAGING:36 testes relevantes, SQL transacional/revertido incluindo retomada,14HTTP reais com transporte suprimido/fixtures limpas, mais rodada real automática de uma mensagem pelo Make6661208 execução de9b565ab0fa4aa8870b9e2687e50b0b/WAMID/sent. Não alegar delivered/read nessa rodada. CopyMake inativa/filtrofalse, flagsSTAGING restauradas, túnel temporário desta rodada encerrado. Original:deploy8bd7be32-dcf6-48dc-969d-a65c0ee24562SUCCESS, importação/quantidade0rejeitada/progresso/JS conferidos sem novos envios; fixturelista própria limpa. Individual+listas+IA+humano ativos, filaoriginal vazia até usuário iniciar; logs observados sem erro de worker. Pastaoriginal atualizada seletivamente8arquivos/backup listas-original-20261016; main/base/.env preservados. Pacote16arquivos/hash2cf603e9d073ba8671b75f339d7cae7834809b6ea430caef2ec12e79991f246f, ainda em publicação. Mestre153225p/223históricas. Senha admin alterada a pedido e login validado, valor omitido. Custos mensais documentados com câmbio hipotético5,50, MetaBRL, Make reservado, Railway10USD eSupabasePro25USD; não são contratos/fatura/carga20mil homologada. Ler docs/VALIDACAO_LISTAS_ORIGINAL_20261016.md e docs/CUSTOS_VENDRA_20261016.md. CODEX/evidências reais preservados; mídia/SMTP/melhorias futuras posteriores.

# Regra vigente por etapa - v1.55 - 16/10/2026

SQL28 aplicado no STAGING e original, sem novo deploy da aplicacao. Novo Lead recebe resposta -> Qualificacao; resposta apos disparo liga IA antes do Make, respeitando pausa manual atual. Qualificacao envia Calendly com WAMID -> Proposta, sem esperar delivered/read. Cinco cards afetados reconciliados e uma IA ativada; backup/auditoria, zero mensagens reenviadas. Ler docs/CORRECAO_REGRAS_POR_ETAPA_20261016.md. Este checkpoint substitui os criterios de primeira mensagem historica/entrega do link da v1.54. SQL29 apenas rollback; nao reaplicar SQL26 anterior. Nova rodada real solicitada ao usuario, ainda nao confirmada.

# Atualizacao comercial de 16/10/2026

Funil original completo e regras de primeira resposta/Calendly/ordenacao aplicadas. Deploy final797c35cf-6a1b-4237-ad3b-f4035bb36b99. Ler docs/VALIDACAO_FUNIS_COMERCIAL_20261016.md; checkpoint vigente sobrepoe pendencias historicas abaixo. SQL25/26 ja executados; SQL27 apenas reversao. Nao reaplicar por copiar o pacote. Comercial preserva controle humano e movimentos manuais; nenhuma campanha iniciada nesta entrega.


## Atualização19/10 — v1.61
Recepção de mídia: SQL32 original autorizado/aplicado, backend e ramo85/86+handlers87/88 ativos no Railway/REV9, healthinboundtrue. Teste automático de novo arquivo solicitado/pendente. Scroll interno sem barra vertical publicado. Evolução10.000cards aprovadaSTAGING (17verificações/74Windows), SQL34somenteSTAGING; promoçãoSQL34originalaguardaautorizaçãoespecífica. Não pausar cenários originais. Ver VALIDACAO_ROLAGEM_FUNIS_20261019.md e VALIDACAO_RECEPCAO_MIDIA_20261019.md.

### Recepção automática original concluída — estado mais recente19/10/2026
Run be3add398da242f18a94b5033408e40b, iniciado00:08:11.930Z20/10 (=21:08Brasília19/10), AUTO, sucesso4,603s/3operações/3créditos. Módulos71/85/86, uma invocação cada, zero erros; nenhum módulo de envio. Callback202accepted/media_storedtrue/duplicatefalse. Nove verificações reais no original: remetente/conta, WAMID gravado, vínculo único, hashMeta, loginadministrativo hospedado, chat, feed, download privado e arquivo completoSHA256. Evidência real preservada. Recepção automática hospedada homologada; solicitação de arquivo final atendida. Pendência separada permaneceSQL34original/paginação10k, não autorizada ainda.
