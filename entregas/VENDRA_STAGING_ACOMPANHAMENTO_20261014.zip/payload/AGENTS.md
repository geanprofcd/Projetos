# Continuidade do VENDRA

## Regras solicitadas pelo usuário

- Desenvolver e validar primeiro no STAGING/cópia de testes. A pasta Windows de acompanhamento é `C:\Users\israe\Downloads\Automações\VENDRA_v0.0.4_Windows_Source\VENDRA_v0.0.4_Windows - Copia\vendra_starter`.
- A cada entrega de código, atualizar o checkout da nuvem e preparar um pacote Windows com os arquivos alterados, hashes, backup e instruções. Se houver acesso real ao Windows, aplicar no destino indicado; nesta sessão não há montagem do disco C: nem ferramenta de acesso remoto. Não afirmar que a pasta Windows foi atualizada quando apenas um pacote foi gerado.
- Atualizar o principal somente depois de a alteração estar correta e homologada. A autorização condicional já foi dada: não pedir novamente permissão genérica para uma promoção cujo escopo e homologação estejam comprovados.
- Testes offline/mocks, publicação do ambiente e um healthcheck isolado não equivalem a homologação funcional. Exigir evidência dos testes relevantes e do fluxo alterado no STAGING, com ausência de regressões materiais. Para comportamento dependente do Windows, registrar também execução no Windows ou evidência informada pelo usuário.
- Promover somente o conjunto efetivamente homologado, com backup e rastreabilidade. Não promover automaticamente o snapshot inteiro de STAGING, os dados de simulação, as credenciais, os arquivos de estado ou as migrations não aplicadas/validadas.
- Não misturar bancos, configurações, sessões ou diretórios de estado do STAGING e do principal. Preservar alterações locais e arquivos `.env`, `.env.h1_005b2`, `.vendra-data`, `runtime` e ambientes virtuais.
- Os scripts SQL e os cenários Make são entregas separadas: copiar seus arquivos não autoriza execução SQL, ativação de worker ou disparo de mensagens.

## Estado observado

Leia `docs/VALIDACAO_ATUAL.md` para o estado mais recente. O código público continua 0.0.25; STAGING inclui H1-005B9 e hotfix PT409 legado. Python local em `/workspace/vendra-runtime/.venv`, constraint externa FastAPI 0.115.14. Não criar worktree: a tarefa de nuvem já é isolada.

O repositório remoto ainda não tem commit inicial confirmado; o código está no checkout local. Não tratar um pacote Windows, um rascunho salvo ou a publicação do ambiente como push para GitHub ou aplicação no computador do usuário.
