# Continuidade do VENDRA

## Regras solicitadas pelo usuário

- Desenvolver e validar primeiro no STAGING/cópia de testes. A pasta Windows de acompanhamento é `C:\Users\israe\Downloads\Automações\VENDRA_v0.0.4_Windows_Source\VENDRA_v0.0.4_Windows - Copia\vendra_starter`.
- A cada entrega de código, atualizar o checkout da nuvem e preparar um pacote Windows com os arquivos alterados, hashes, backup e instruções. Se houver acesso real ao Windows, aplicar no destino indicado; nesta sessão não há montagem do disco C: nem ferramenta de acesso remoto. Não afirmar que a pasta Windows foi atualizada quando apenas um pacote foi gerado.
- Fornecer sempre os links completos e clicáveis usados na entrega, inclusive para as próximas atualizações. O usuário autorizou disponibilizar pacotes em uma branch de entregas no GitHub `geanprofcd/Projetos`. Preferir links GitHub verificados: o download de artefatos desta interface falhou. Informar o link do arquivo, o download direto quando funcional e as instruções; não publicar segredos, dados locais ou promover ao principal por efeito da entrega.
- A cada atualização, incluir um resumo breve do que foi aplicado, onde foi aplicado, qual validação ocorreu e em que etapa está o desenvolvimento. Distinguir mudanças já executadas na nuvem de pacotes entregues ainda não aplicados/validados no Windows; concluir com a próxima etapa concreta, sem tratar testes offline como homologação funcional.
- Atualizar o principal somente depois de a alteração estar correta e homologada. A autorização condicional já foi dada: não pedir novamente permissão genérica para uma promoção cujo escopo e homologação estejam comprovados.
- Testes offline/mocks, publicação do ambiente e um healthcheck isolado não equivalem a homologação funcional. Exigir evidência dos testes relevantes e do fluxo alterado no STAGING, com ausência de regressões materiais. Para comportamento dependente do Windows, registrar também execução no Windows ou evidência informada pelo usuário.
- Promover somente o conjunto efetivamente homologado, com backup e rastreabilidade. Não promover automaticamente o snapshot inteiro de STAGING, os dados de simulação, as credenciais, os arquivos de estado ou as migrations não aplicadas/validadas.
- Não misturar bancos, configurações, sessões ou diretórios de estado do STAGING e do principal. Preservar alterações locais e arquivos `.env`, `.env.h1_005b2`, `.vendra-data`, `runtime` e ambientes virtuais.
- Os scripts SQL e os cenários Make são entregas separadas: copiar seus arquivos não autoriza execução SQL, ativação de worker ou disparo de mensagens.

## Estado observado

Leia `docs/VALIDACAO_ATUAL.md` para o estado mais recente. O código público continua 0.0.25; STAGING inclui H1-005B9 e hotfix PT409 legado. Python local em `/workspace/vendra-runtime/.venv`, constraint externa FastAPI 0.115.14. Não criar worktree: a tarefa de nuvem já é isolada.

O GitHub tem uma branch de entregas `entregas/staging-20261014` com ZIP e instruções, publicada com autorização do usuário. O código-fonte de desenvolvimento ainda está no checkout local sem commit na branch de trabalho. Não tratar a publicação do ZIP como promoção ao principal ou aplicação no computador do usuário.

O usuário executou o pacote no Windows: 156 testes passaram e um erro de leitura CP1252 impediu sucesso completo. Usar Python `-X utf8` nos comandos Windows, inclusive testes e startup; não alterar assertions ou converter arquivos UTF-8 para contornar a falha. A correção do instalador e a evidência estão em `docs/VALIDACAO_WINDOWS_UTF8.md`.
